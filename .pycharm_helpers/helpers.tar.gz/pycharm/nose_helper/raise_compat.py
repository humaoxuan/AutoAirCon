try:
    from nose_helper._2 import *
except (ImportError, SyntaxError):
    from nose_helper._3 import *

